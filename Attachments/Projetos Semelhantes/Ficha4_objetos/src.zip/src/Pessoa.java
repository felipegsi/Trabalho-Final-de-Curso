public class Pessoa {
    private String nome;
    private String apelido;

    public Pessoa(String nome, String apelido) {
        this.nome = nome;
        this.apelido = apelido;
    }

    @Override
    public String toString() {
        return "Bom dia, chamo-me" + nome + " " + apelido;
    }
}
