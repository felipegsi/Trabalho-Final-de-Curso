public class Main {
    public static void main(String[] args) {
        System.out.println(multiplica(4,3));
        System.out.println(tabuadaEmLinha(5,1));
        System.out.println(linhaDeAsteriscos(5));
        System.out.println(arvoreNatal(4));
    }
    static long multiplica(int n1, int n2){
        if (n1 <= 0){
            return 0;
        }
        return multiplica(n1 - 1, n2) + n2;
    }

    static String tabuadaEmLinha(int numero, int multiplicador){
        if (multiplicador >= 10){
            return "";
        }else {
            if (multiplicador == 9){
                return multiplica(numero, multiplicador + 1) +
                        tabuadaEmLinha(numero, multiplicador + 1) ;
            }else {
                if (multiplicador == 1){
                    return  numero + "," + numero*2 + "," +
                            tabuadaEmLinha(numero, multiplicador + 1) ;
                }else {
                    return multiplica(numero, multiplicador + 1) +  "," +
                            tabuadaEmLinha(numero, multiplicador + 1) ;
                }

            }
        }
    }

    static String linhaDeAsteriscos(int dimensao){
        if(dimensao <= 0){
            return "";
        }
        return linhaDeAsteriscos(dimensao - 1) + "*";
    }

    static String arvoreNatal(int altura){
        if (altura <= 0){
            return "";
        }
        return arvoreNatal(altura - 1) + linhaDeAsteriscos(altura) + "\n";
    }

}