public class Main {
    public static void main(String[] args) {
        //System.out.println(multiplica(4,3));
        System.out.println(tabuadaEmLinha(5,1));
     //   System.out.println(linhaDeAsteriscos(5));
      //  System.out.println(arvoreNatal(4));
    }
    static long multiplica(int n1, int n2){
        if (n1 <= 0){
            return 0;
        }
        return multiplica(n1 - 1, n2) + n2;
    }
    

    static String linhaDeAsteriscos(int dimensao){
        if(dimensao <= 0){
            return "";
        }
        return linhaDeAsteriscos(dimensao - 1) + "*";
    }



    static String arvoreNatal(int altura) {
        if (altura <= 0) {
            return "";
        }
        // Construa a árvore de cima para baixo, adicionando o '\n' antes das linhas, exceto para a primeira.
        String arvore = arvoreNatal(altura - 1);
        // Adicione o '\n' apenas se não for a primeira linha.
        if (!arvore.isEmpty()) {
            arvore += "\n";
        }
        // Adicione a linha de asteriscos da altura atual.
        arvore += linhaDeAsteriscos(altura);
        return arvore;
    }
    static String tabuadaEmLinha(int numero, int multiplicador) {
        if (multiplicador > 10) {
            return "";
        }

        String tabuada = multiplica(numero, multiplicador) + "";

        if (multiplicador < 10){
            tabuada += "," + tabuadaEmLinha(numero, multiplicador + 1);
        }

        return tabuada;

    }



}

