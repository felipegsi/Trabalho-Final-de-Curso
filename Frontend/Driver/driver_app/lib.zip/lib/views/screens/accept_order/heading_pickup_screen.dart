import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher_string.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_background_geolocation/flutter_background_geolocation.dart'
    as bg;
import '../../../api/order_api.dart';
import '../../../models/order.dart';
import '../../../services/location_service.dart';

class HeadingPickupScreen extends StatefulWidget {
  final int orderId;

  const HeadingPickupScreen({
    super.key,
    required this.orderId,
  });

  @override
  _HeadingPickupScreenState createState() => _HeadingPickupScreenState();
}

class _HeadingPickupScreenState extends State<HeadingPickupScreen> {
  GoogleMapController? mapController;
  List<LatLng> points = [];
  bool isLoading = false;
  LatLng? _currentLocation;
  Marker? originMarker;
  Marker? destinationMarker;
  double distance = 0.0;

  @override
  void initState() {
    super.initState();
    _initialize();
    _configureBackgroundGeolocation();
  }

  void _configureBackgroundGeolocation() {
    bg.BackgroundGeolocation.onLocation((bg.Location location) {
      print('[location] - $location');
      _sendLocationToServer(location);
    });

    bg.BackgroundGeolocation.onMotionChange((bg.Location location) {
      print('[motionchange] - $location');
    });

    bg.BackgroundGeolocation.onActivityChange((bg.ActivityChangeEvent event) {
      print('[activitychange] - ${event.activity} - ${event.confidence}');
    });

    bg.BackgroundGeolocation.ready(bg.Config(
      desiredAccuracy: bg.Config.DESIRED_ACCURACY_HIGH,
      distanceFilter: 10.0,
      // Para obter atualizações de localização a cada 10 metros
      stopOnTerminate: false,
      // Para manter o serviço em execução
      startOnBoot: true,
      // Para iniciar o serviço em segundo plano
      debug: true,
      // Para depuração, remova em produção
      logLevel: bg.Config.LOG_LEVEL_VERBOSE,
      // Para depuração, remova em produção
      url: 'http://10.0.2.2:8080/driver/',
      autoSync: true,
      params: {
        'user_id': '123', // Substitua pelo ID do usuário
      },
      headers: {
        'Authorization': 'Bearer ...', // Substitua pelo token de autorização
        'Content-Type': 'application/json',
      },
    )).then((bg.State state) {
      if (!state.enabled) {
        bg.BackgroundGeolocation.start();
      }
    });
  }

  void _sendLocationToServer(bg.Location location) async {
    try {
      final response = await http.post(
        Uri.parse('http://10.0.2.2:8080/driver/'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ...',
        },
        body: jsonEncode({
          'latitude': location.coords.latitude,
          'longitude': location.coords.longitude,
        }),
      );

      if (response.statusCode == 200) {
        print('Localização enviada com sucesso');
      } else {
        print('Falha ao enviar localização');
      }
    } catch (e) {
      print('Erro ao enviar localização: $e');
    }
  }

  void _initializeMapMarkers(Order order) {
    if (_currentLocation == null) return;

    final origin = parseLatLng(order.origin);

    destinationMarker = Marker(
      markerId: const MarkerId('destination'),
      position: origin,
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
    );

    setState(() {});
  }

  Future<void> _initialize() async {
    await _determinePosition();
    if (_currentLocation != null) {
      final orderApi = Provider.of<OrderApi>(context, listen: false);
      await orderApi.getOrderById(widget.orderId);
      final order = orderApi.order;
      if (order != null) {
        _initializeMapMarkers(order);
        await getRoute(parseLatLng(order.origin));
      }
    }
  }

  Future<void> _determinePosition() async {
    LocationService location = LocationService();
    _currentLocation = await location.determinePosition();
  }

  LatLng parseLatLng(String coordinate) {
    final coordinates = coordinate.split(',').map(double.parse).toList();
    return LatLng(coordinates[0], coordinates[1]);
  }

  Future<void> getRoute(LatLng origin) async {
    if (_currentLocation == null) return;

    setState(() => isLoading = true);

    const String apiKey = 'AIzaSyDWkqwPVu8yCPdeR3ynYX-a8VHco5kS-Ik';
    final String url =
        'https://maps.googleapis.com/maps/api/directions/json?origin=${_currentLocation!.latitude},${_currentLocation!.longitude}&destination=${origin.latitude},${origin.longitude}&key=$apiKey';

    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        final routes = jsonResponse['routes'];
        if (routes.isEmpty) throw Exception('No routes found');

        final String encodedPolyline = routes[0]['overview_polyline']['points'];
        PolylinePoints polylinePoints = PolylinePoints();
        List<PointLatLng> decodedPoints =
            polylinePoints.decodePolyline(encodedPolyline);

        distance = routes[0]['legs'][0]['distance']['value'] / 1000;

        setState(() {
          points = decodedPoints
              .map((point) => LatLng(point.latitude, point.longitude))
              .toList();
          isLoading = false;
        });

        adjustRouteMode();
      } else {
        throw Exception('Failed to fetch route: ${response.statusCode}');
      }
    } catch (e) {
      setState(() => isLoading = false);
      print(e);
    }
  }

  void adjustRouteMode() {
    if (mapController != null && points.isNotEmpty) {
      LatLngBounds bounds;
      if (points.length == 1) {
        bounds = LatLngBounds(
          southwest: LatLng(
              points.first.latitude - 0.01, points.first.longitude - 0.01),
          northeast: LatLng(
              points.first.latitude + 0.01, points.first.longitude + 0.01),
        );
      } else {
        bounds = LatLngBounds(
          southwest: points.reduce((a, b) => LatLng(
              a.latitude < b.latitude ? a.latitude : b.latitude,
              a.longitude < b.longitude ? a.longitude : b.longitude)),
          northeast: points.reduce((a, b) => LatLng(
              a.latitude > b.latitude ? a.latitude : b.latitude,
              a.longitude > b.longitude ? a.longitude : b.longitude)),
        );
      }

      mapController!.animateCamera(CameraUpdate.newLatLngBounds(bounds, 50));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Heading to Pickup'),
      ),
      body: Consumer<OrderApi>(
        builder: (context, orderApi, child) {
          final order = orderApi.order;
          if (order == null) {
            return const Center(child: CircularProgressIndicator());
          } else {
            return Stack(
              children: [
                buildMap(),
                buildMenu(order),
              ],
            );
          }
        },
      ),
    );
  }

  Widget buildMap() {
    return GoogleMap(
      onMapCreated: (controller) {
        mapController = controller;
        adjustRouteMode();
      },
      initialCameraPosition: CameraPosition(
          target: _currentLocation ?? const LatLng(38.758072, -9.153414),
          zoom: 5.0),
      markers: {
        if (originMarker != null) originMarker!,
        if (destinationMarker != null) destinationMarker!
      },
      myLocationEnabled: true,
      zoomControlsEnabled: false,
      myLocationButtonEnabled: false,
      polylines: {
        if (points.isNotEmpty)
          Polyline(
            polylineId: const PolylineId('route'),
            points: points,
            color: Colors.blue,
            width: 4,
          ),
      },
    );
  }

  Widget buildMenu(Order order) {
    return Positioned(
      bottom: 30.0,
      left: 20.0,
      right: 20.0,
      child: Container(
        padding: const EdgeInsets.all(15.0),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10.0),
          boxShadow: const [
            BoxShadow(
              color: Colors.black26,
              blurRadius: 10.0,
              spreadRadius: 1.0,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const SizedBox(height: 5),
            buildOrderDetails(order),
            const SizedBox(height: 5),
          ],
        ),
      ),
    );
  }

  Widget buildOrderDetails(Order order) {
    return Column(
      children: [
        Text(
          'Distance to pickup: ${distance.toStringAsFixed(2)} km',
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        if (order.weight != null)
          Text('Weight: ${order.weight} kg',
              style: const TextStyle(fontSize: 14)),
        if (order.width != null && order.height != null && order.length != null)
          Text(
              'Dimensions: ${order.width} x ${order.height} x ${order.length} cm',
              style: const TextStyle(fontSize: 14)),
        if (order.plate != null)
          Text('Vehicle Plate: ${order.plate}',
              style: const TextStyle(fontSize: 14)),
        if (order.model != null)
          Text('Vehicle Model: ${order.model}',
              style: const TextStyle(fontSize: 14)),
        if (order.brand != null)
          Text('Vehicle Brand: ${order.brand}',
              style: const TextStyle(fontSize: 14)),
        navigateButton(),
      ],
    );
  }

  Widget navigateButton() {
    return Positioned(
      top: MediaQuery.of(context).size.height * 0.55,
      right: 11.0,
      bottom: 125,
      child: ElevatedButton(
        onPressed: _launchGoogleMaps,
        style: ElevatedButton.styleFrom(
          shape: const CircleBorder(),
          padding: const EdgeInsets.all(15),
        ),
        child: const Icon(FontAwesomeIcons.locationArrow),
      ),
    );
  }

  void _launchGoogleMaps() async {
    if (_currentLocation == null || destinationMarker == null) return;

    final LatLng destination = destinationMarker!.position;
    final String googleMapsUrl =
        'google.navigation:q=${destination.latitude},${destination.longitude}&mode=d';

    if (await canLaunchUrlString(googleMapsUrl)) {
      await launchUrlString(googleMapsUrl);
    } else {
      throw 'Could not launch $googleMapsUrl';
    }
  }
}
