// Defina um enum para as rotas para maior clareza e prevenção de erros
enum AppRoute { login, register, orderHistory, profile }

