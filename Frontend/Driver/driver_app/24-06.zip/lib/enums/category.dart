//enum categoria
enum Category {
  SMALL,
  MEDIUM,
  LARGE,
  MOTORIZED
}