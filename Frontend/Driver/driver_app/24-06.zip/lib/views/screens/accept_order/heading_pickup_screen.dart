import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher_string.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import '../../../api/order_api.dart';
import '../../../models/order.dart';
import '../../../services/location_service.dart';

class HeadingPickupScreen extends StatefulWidget {
  final int orderId;

  const HeadingPickupScreen({
    super.key,
    required this.orderId,
  });

  @override
  _HeadingPickupScreenState createState() => _HeadingPickupScreenState();
}

class _HeadingPickupScreenState extends State<HeadingPickupScreen> {
  GoogleMapController? mapController;
  List<LatLng> points = [];
  bool isLoading = true;
  LatLng? _currentLocation;
  LatLng? _lastKnownLocation;
  Marker? destinationMarker;
  double distance = 0.0;
  late StreamSubscription<Position> _positionStream;
  Order? orderHere;
  String duration = '';

  @override
  void initState() {
    super.initState();
    _initialize();
    _startLocationUpdates();
  }

  @override
  void dispose() {
    _positionStream.cancel();
    super.dispose();
  }

  Future<void> _initialize() async {
    await _determinePosition();
    if (_currentLocation != null) {
      final orderApi = Provider.of<OrderApi>(context, listen: false);
      await orderApi.getOrderById(widget.orderId);
      orderHere = orderApi.order;

      if (orderHere != null) {
        _initializeMapMarkers(orderHere!);
        await _getRouteToOrigin();
      }
    }
  }

  void _startLocationUpdates() {
    _positionStream = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.best,
        distanceFilter: 30,
      ),
    ).listen((Position position) {
      _updateCurrentLocation(position);
    });
  }

  void _updateCurrentLocation(Position position) async {
    if (position.accuracy < 30) {
      _currentLocation = LatLng(position.latitude, position.longitude);
      final newLocation = LatLng(position.latitude, position.longitude);

      if (_lastKnownLocation == null ||
          _hasMovedSignificantly(_lastKnownLocation!, newLocation)) {
        _lastKnownLocation = newLocation;
        mapController?.animateCamera(CameraUpdate.newLatLng(newLocation));

        if (orderHere?.origin != null) {
          points.clear();
          setState(() {});
          final orderApi = Provider.of<OrderApi>(context, listen: false);
          orderApi.sendLocationToServer(
              '${position.latitude}, ${position.longitude}');
          await _getRouteToOrigin();
        }
      }
    }
  }

  bool _hasMovedSignificantly(LatLng oldLocation, LatLng newLocation) {
    return Geolocator.distanceBetween(
          oldLocation.latitude,
          oldLocation.longitude,
          newLocation.latitude,
          newLocation.longitude,
        ) >
        30;
  }

  Future<void> _determinePosition() async {
    final locationService = LocationService();
    _currentLocation = await locationService.determinePosition();
    _lastKnownLocation = _currentLocation;
    print('Localização atual: $_currentLocation \n\n');
  }

  void _initializeMapMarkers(Order order) {
    if (_currentLocation == null) return;

    final origin = _parseLatLng(order.origin);

    destinationMarker = Marker(
      markerId: const MarkerId('destination'),
      position: origin,
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
    );

    setState(() {});
  }

  LatLng _parseLatLng(String coordinate) {
    final coords = coordinate.split(',').map(double.parse).toList();
    return LatLng(coords[0], coords[1]);
  }

  Future<void> _getRouteToOrigin() async {
    if (_currentLocation == null) return;

    setState(() => isLoading = true);

    const apiKey = 'AIzaSyDWkqwPVu8yCPdeR3ynYX-a8VHco5kS-Ik';
    final origin = _parseLatLng(orderHere!.origin);
    final url = 'https://maps.googleapis.com/maps/api/directions/json?'
        'origin=${_currentLocation!.latitude},${_currentLocation!.longitude}'
        '&destination=${origin.latitude},${origin.longitude}&key=$apiKey';

    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        final routes = jsonResponse['routes'];
        if (routes.isEmpty) throw Exception('No routes found');

        final encodedPolyline = routes[0]['overview_polyline']['points'];
        final polylinePoints = PolylinePoints().decodePolyline(encodedPolyline);

        distance = routes[0]['legs'][0]['distance']['value'] / 1000;
        duration = routes[0]['legs'][0]['duration']['text'];

        setState(() {
          points = polylinePoints
              .map((point) => LatLng(point.latitude, point.longitude))
              .toList();
          isLoading = false;
        });
      } else {
        throw Exception('Failed to fetch route: ${response.statusCode}');
      }
    } catch (e) {
      setState(() => isLoading = false);
      print(e);
    }
  }

  void _adjustRouteMode() {
    if (mapController != null && points.isNotEmpty) {
      LatLngBounds bounds = _calculateLatLngBounds(points);
      mapController!.animateCamera(CameraUpdate.newLatLngBounds(bounds, 50));
    }
  }

  LatLngBounds _calculateLatLngBounds(List<LatLng> points) {
    if (points.length == 1) {
      final singlePoint = points.first;
      return LatLngBounds(
        southwest:
            LatLng(singlePoint.latitude - 0.01, singlePoint.longitude - 0.01),
        northeast:
            LatLng(singlePoint.latitude + 0.01, singlePoint.longitude + 0.01),
      );
    } else {
      return LatLngBounds(
        southwest: LatLng(
          points.map((e) => e.latitude).reduce((a, b) => a < b ? a : b),
          points.map((e) => e.longitude).reduce((a, b) => a < b ? a : b),
        ),
        northeast: LatLng(
          points.map((e) => e.latitude).reduce((a, b) => a > b ? a : b),
          points.map((e) => e.longitude).reduce((a, b) => a > b ? a : b),
        ),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Heading to Pickup',
          style: TextStyle(color: Colors.black),
        ),
        backgroundColor: Colors.white,
        elevation: 0, // Remove a sombra da AppBar
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : Stack(
        children: [
          _buildMap(),
          Positioned(
            // Colocar o botão de navegação um pouco abaixo da metade do mapa
            bottom: MediaQuery.of(context).size.height * 0.29,
            right: 20.0,
            child: _navigateButton(),
          ),
          if (orderHere != null) _buildMenu(orderHere!),
        ],
      ),
    );
  }

  Widget _buildMap() {
    return GoogleMap(
      onMapCreated: (controller) {
        mapController = controller;
        _adjustRouteMode();
      },
      initialCameraPosition: CameraPosition(
        target: _currentLocation ?? const LatLng(38.758072, -9.153414),
        zoom: 16.0,
      ),
      markers: {
        if (destinationMarker != null) destinationMarker!,
      },
      myLocationEnabled: true,
      zoomControlsEnabled: false,
      myLocationButtonEnabled: true,
      polylines: {
        if (points.isNotEmpty)
          Polyline(
            polylineId: const PolylineId('route'),
            points: points,
            color: Colors.blue,
            width: 4,
          ),
      },
    );
  }

  Widget _buildMenu(Order order) {
    return Positioned(
      bottom: 30.0,
      left: 20.0,
      right: 20.0,
      child: Container(
        padding: const EdgeInsets.all(15.0),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15.0), // Cantos arredondados
          boxShadow: const [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 10.0,
              spreadRadius: 1.0,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const SizedBox(height: 5),
            _buildOrderDetails(order),
            const SizedBox(height: 5),
          ],
        ),
      ),
    );
  }

  Widget _navigateButton() {
    return FloatingActionButton(
      onPressed: _launchGoogleMaps,
      backgroundColor: Colors.blue,
      child: const Icon(FontAwesomeIcons.map, color: Colors.white),
    );
  }

  //TODO : EMBAIXO DO APP BAR NO CENTRO COLOCAR UMA LABEL COM UMA MENSAGEM INDICANDO O STATUS DO PEDIDO
  Widget _buildOrderDetails(Order order) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center, // Alinhamento ao centro
      children: [
        // Duração com ícone
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(FontAwesomeIcons.clock, size: 16),
            const SizedBox(width: 5),
            Text(
              duration,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        const SizedBox(height: 5),
        // Distância com ícone
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(FontAwesomeIcons.route, size: 16),
            const SizedBox(width: 5),
            Text(
              '${distance.toStringAsFixed(2)} km',
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        const SizedBox(height: 5),
        // Status com ícone
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(FontAwesomeIcons.infoCircle, size: 16),
            const SizedBox(width: 5),
            Text(
              '${order.status}',
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        const SizedBox(height: 10),
        // Peso com ícone
        if (order.weight != null)
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(FontAwesomeIcons.weight, size: 16),
              const SizedBox(width: 5),
              Text(
                'Weight: ${order.weight} kg',
                style: const TextStyle(fontSize: 14),
              ),
            ],
          ),
        if (order.width != null && order.height != null && order.length != null)
          const SizedBox(height: 5),
        // Dimensões com ícone
        if (order.width != null && order.height != null && order.length != null)
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(FontAwesomeIcons.cube, size: 16),
              const SizedBox(width: 5),
              Text(
                'Dimensions: ${order.width} x ${order.height} x ${order.length} cm',
                style: const TextStyle(fontSize: 14),
              ),
            ],
          ),
        if (order.plate != null) const SizedBox(height: 5),
        // Placa do veículo com ícone
        if (order.plate != null)
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(FontAwesomeIcons.car, size: 16),
              const SizedBox(width: 5),
              Text(
                'Vehicle Plate: ${order.plate}',
                style: const TextStyle(fontSize: 14),
              ),
            ],
          ),
        if (order.brand != null && order.model != null) const SizedBox(height: 5),
        // Marca e modelo do veículo com ícone
        if (order.brand != null && order.model != null)
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(FontAwesomeIcons.car, size: 16),
              const SizedBox(width: 5),
              Text(
                '${order.brand} - ${order.model}',
                style: const TextStyle(fontSize: 14),
              ),
            ],
          ),
        const SizedBox(height: 10), // Espaçamento antes do botão
        // Botão de confirmação
        if (distance < 0.700)
          ElevatedButton(
            onPressed: _changeOrderStatus,
            style: ElevatedButton.styleFrom(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8.0),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(FontAwesomeIcons.check, size: 16),
                const SizedBox(width: 5),
                const Text('I picked up the order'),
              ],
            ),
          ),
      ],
    );
  }

  void _changeOrderStatus() {
    final orderApi = Provider.of<OrderApi>(context, listen: false);
    orderApi.pickupOrderStatus(widget.orderId);
  }

  void _launchGoogleMaps() async {
    if (_currentLocation == null || destinationMarker == null) return;

    final destination = destinationMarker!.position;
    final googleMapsUrl =
        'google.navigation:q=${destination.latitude},${destination.longitude}&mode=d';

    if (await canLaunchUrlString(googleMapsUrl)) {
      await launchUrlString(googleMapsUrl);
    } else {
      throw 'Could not launch $googleMapsUrl';
    }
  }
}
