import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import '../../../api/location_api.dart';
import '../../../api/order_api.dart';
import '../../../models/driver.dart';
import '../../../models/order.dart';

class SearchingDriverScreen extends StatefulWidget {
  final Order order;

  const SearchingDriverScreen({super.key, required this.order});

  @override
  _SearchingDriverScreenState createState() => _SearchingDriverScreenState();
}

class _SearchingDriverScreenState extends State<SearchingDriverScreen> {
  GoogleMapController? mapController;
  Driver? assignedDriver;
  bool isLoading = true;
  bool _hasCalledAssignOrderToDriver = false;
  late LatLng initialLocation;
  ValueNotifier<double?> distanceNotifier = ValueNotifier(null);
  StreamSubscription? _locationUpdateSubscription;
  final _debounceDuration = const Duration(seconds: 10);
  Timer? _debounceTimer;

  @override
  void initState() {
    super.initState();
    initialLocation = _convertToLatLng(widget.order.origin);
  }

  @override
  void dispose() {
    _locationUpdateSubscription?.cancel();
    distanceNotifier.dispose();
    _debounceTimer?.cancel();
    super.dispose();
  }

  Future<void> _assignOrderToDriver(OrderApi orderApi) async {
    setState(() {
      isLoading = true;
    });

    try {
      Driver driver = await orderApi.assignOrderToDriver(widget.order.id!);
      print('Driver assigned: ${driver.id}');

      _moveCameraToDriver(driver);

      assignedDriver = driver;
      isLoading = false;

      _startLocationUpdates(orderApi, driver);
    } catch (error) {
      isLoading = false;
      _showErrorDialog('Failed to assign order to driver: $error');
    }
  }

  void _startLocationUpdates(OrderApi orderApi, Driver driver) {
    _locationUpdateSubscription = Stream.periodic(_debounceDuration)
        .asyncMap((_) => orderApi.getDriverLocation(driver.id))
        .listen((location) {
      driver.location = location;
      _updateDriverMarker(driver);
    }, onError: (error) {
      print('Failed to update driver location: $error');
    });
  }

  void _showErrorDialog(String message) {
    if (mounted) {
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text('Error'),
            content: Text(message),
            actions: [
              TextButton(
                child: const Text('OK'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );
    }
  }

  Future<void> _onMapCreated(GoogleMapController controller, OrderApi orderApi) async {
    mapController = controller;
    await Future.delayed(const Duration(seconds: 3));

    if (!_hasCalledAssignOrderToDriver) {
      _hasCalledAssignOrderToDriver = true;
      await _assignOrderToDriver(orderApi);
    }
  }

  LatLng _convertToLatLng(String coordinates) {
    List<String> coords = coordinates.split(',');
    return LatLng(double.parse(coords[0]), double.parse(coords[1]));
  }

  void _moveCameraToDriver(Driver driver) {
    if (mapController != null) {
      mapController?.moveCamera(
        CameraUpdate.newLatLngZoom(
          _convertToLatLng(driver.location),
          17.0,
        ),
      );
    }
  }

  void _updateDriverMarker(Driver driver) {
    if (mapController != null) {
      setState(() {
        // Atualiza o marcador do motorista com a nova localização
      });
      mapController?.moveCamera(
        CameraUpdate.newLatLng(
          _convertToLatLng(driver.location),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Searching Driver'),
      ),
      body: Stack(
        children: [
          Consumer<OrderApi>(
            builder: (context, orderApi, _) {
              return GoogleMap(
                onMapCreated: (controller) async => await _onMapCreated(controller, orderApi),
                initialCameraPosition: CameraPosition(
                  target: initialLocation,
                  zoom: 17.0,
                ),
                markers: _buildMarkers(),
                zoomControlsEnabled: false,
              );
            },
          ),
          if (isLoading)
            const Center(
              child: CircularProgressIndicator(),
            ),
          if (assignedDriver != null) _buildDriverInfo(),
        ],
      ),
    );
  }

  Set<Marker> _buildMarkers() {
    Set<Marker> markers = {};

    if (assignedDriver != null) {
      markers.add(Marker(
        markerId: const MarkerId('driver'),
        position: _convertToLatLng(assignedDriver!.location),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueViolet),
        infoWindow: InfoWindow(
          title: 'Driver: ${assignedDriver!.name}',
          snippet: 'Vehicle: ${assignedDriver!.vehicle}',
        ),
      ));
    }

    return markers;
  }

  Widget _buildDriverInfo() {
    return Positioned(
      bottom: 30.0,
      left: 20.0,
      right: 20.0,
      child: Container(
        padding: const EdgeInsets.all(15.0),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10.0),
          boxShadow: const [
            BoxShadow(
              color: Colors.black26,
              blurRadius: 10.0,
              spreadRadius: 1.0,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Driver: ${assignedDriver!.name}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Text('Vehicle: ${assignedDriver!.vehicle.model} ${assignedDriver!.vehicle.brand}', style: const TextStyle(fontSize: 14)),
            Text('Plate: ${assignedDriver!.vehicle.plate}', style: const TextStyle(fontSize: 14)),
            ValueListenableBuilder<double?>(
              valueListenable: distanceNotifier,
              builder: (context, distance, child) {
                if (distance != null) {
                  return Text('Distance: ${distance.toStringAsFixed(2)} km', style: const TextStyle(fontSize: 14));
                }
                return Container();
              },
            ),
          ],
        ),
      ),
    );
  }
}
