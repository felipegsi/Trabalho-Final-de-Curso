import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SearchRoute extends StatelessWidget{




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Search Route'),
      ),
      body: Center(
        child: Text('This is the search page'),
      ),);
  }
}
