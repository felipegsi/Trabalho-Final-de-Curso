package com.project.uber.service.interfac;

import com.project.uber.dtos.DriverDto;
import com.project.uber.dtos.OrderDto;
import com.project.uber.enums.Category;
import com.project.uber.enums.OrderStatus;
import com.project.uber.infra.exceptions.BusinessException;
import com.project.uber.model.Driver;
import com.project.uber.model.Order;
import jakarta.transaction.Transactional;

import java.math.BigDecimal;
import java.util.List;

public interface OrderService {

    List<BigDecimal> estimateAllCategoryOrderCost(String origin, String destination);


    public OrderDto saveOrder(OrderDto orderDto, Long clientId);

    OrderDto getOrderDtoById(Long orderId) throws BusinessException;

    public List<Order> getClientOrderHistory(Long clientId);

    @Transactional
    void confirmPickUp(Long orderId, Long driverId) throws Exception;

    @Transactional
    void updateOrderStatus(Long orderId, OrderStatus newStatus, Long driverId) throws Exception;

   // List<OrderDto> getDriverOrderHistory(Long driverId);


    BigDecimal estimateOrderCost(String origin, String destination, Category category,
                                 Integer width, Integer height, Integer length, Float weight) throws BusinessException ;
        // Use valores padrão se forem nulos

        DriverDto assignOrderToDriver(Long orderId);
}