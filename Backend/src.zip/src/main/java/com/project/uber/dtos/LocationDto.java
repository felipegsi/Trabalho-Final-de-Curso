package com.project.uber.dtos;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LocationDto {
    private String latitude;
    private String longitude;

}
