package com.project.uber.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DriverResponse {
    private Long orderId;
    private String response;
}