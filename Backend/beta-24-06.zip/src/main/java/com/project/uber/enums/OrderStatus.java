package com.project.uber.enums;

public enum OrderStatus {
    PENDING,
    ACCEPTED,
    PICKED_UP,
    COMPLETED,
    CANCELLED
}
