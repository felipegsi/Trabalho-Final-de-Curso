package com.project.uber.enums;

public enum Category {
    SMALL,
    MEDIUM,
    LARGE,
    MOTORIZED
}
