package com.project.uber.dtos;

public record RegistrationDto(
        String name,
        String email,
        String birthdate,
        String phoneNumber,
        int taxPayerNumber,
        String street,
        String city,
        int postalCode,
        VehicleDto vehicleDto,
        String password
) {
}
