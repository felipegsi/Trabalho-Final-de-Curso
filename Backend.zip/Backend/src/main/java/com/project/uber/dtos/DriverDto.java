package com.project.uber.dtos;

import com.project.uber.model.Vehicle;

public record DriverDto(
        String name,
        String email,

        String birthdate,
        String phoneNumber,
        int taxPayerNumber,
        String street,
        String city,
        int postalCode,
        VehicleDto vehicleDto // Use a classe DTO para `Vehicle`
) {
    public DriverDto(String name, String email, String formattedBirthdate, String phoneNumber, int taxPayerNumber, String street, String city, int postalCode, Vehicle vehicle) {
        this(name, email, formattedBirthdate, phoneNumber, taxPayerNumber, street, city, postalCode, VehicleDto.fromVehicle(vehicle));
    }

    // Método estático de fábrica que aceita um Vehicle e constrói um VehicleDto
    public static DriverDto from(String name, String email, String birthdate, String phoneNumber,
                                 int taxPayerNumber, String street, String city, int postalCode, Vehicle vehicle) {
        VehicleDto vehicleDto = new VehicleDto(String.valueOf(vehicle.getVehicleType()), vehicle.getYear(), vehicle.getPlate(),
                vehicle.getBrand(), vehicle.getModel(), vehicle.getCapacity());
        return new DriverDto(name, email, birthdate, phoneNumber, taxPayerNumber, street, city, postalCode, vehicleDto);
    }



}
